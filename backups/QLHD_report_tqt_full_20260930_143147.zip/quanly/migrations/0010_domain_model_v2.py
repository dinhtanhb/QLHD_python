from django.db import migrations, models
from django.utils import timezone
import django.db.models.deletion
from decimal import Decimal


MASTER_TIMESTAMP_FIELDS = [
    migrations.AddField(
        model_name="tinh", name="created_at",
        field=models.DateTimeField(auto_now_add=True, default=timezone.now, verbose_name="Ngày tạo"),
        preserve_default=False,
    ),
    migrations.AddField(
        model_name="tinh", name="updated_at",
        field=models.DateTimeField(auto_now=True, verbose_name="Ngày cập nhật"),
    ),
]


def drop_renamed_hopdong_canbo_fk(apps, schema_editor):
    """MySQL keeps the old FK name after RenameModel(HopDong -> PhanBoChiTieu).

    Migration 0010 creates a new HopDong table with the same generated FK name.
    Remove only the stale FK on the renamed table, and only when it is present.
    Other database backends and already-normalized schemas are no-ops.
    """
    connection = schema_editor.connection
    if connection.vendor != "mysql":
        return

    with connection.cursor() as cursor:
        cursor.execute(
            """
            SELECT CONSTRAINT_NAME
            FROM information_schema.KEY_COLUMN_USAGE
            WHERE CONSTRAINT_SCHEMA = DATABASE()
              AND TABLE_NAME = %s
              AND COLUMN_NAME = %s
              AND REFERENCED_TABLE_NAME = %s
            """,
            ["quanly_phanbochitieu", "can_bo_id", "quanly_canbo"],
        )
        constraint_names = [row[0] for row in cursor.fetchall()]
        for constraint_name in constraint_names:
            safe_name = str(constraint_name).replace("`", "``")
            schema_editor.execute(
                f"ALTER TABLE `quanly_phanbochitieu` DROP FOREIGN KEY `{safe_name}`"
            )


class Migration(migrations.Migration):
    dependencies = [("quanly", "0009_phanbochitieu_tham_gia_ct_and_more")]

    operations = [
        # Master data: bổ sung trạng thái và audit timestamps.
        *MASTER_TIMESTAMP_FIELDS,
        migrations.AddField(model_name="tinh", name="is_active", field=models.BooleanField(default=True, verbose_name="Đang sử dụng")),
        migrations.AddField(model_name="xa", name="created_at", field=models.DateTimeField(auto_now_add=True, default=timezone.now, verbose_name="Ngày tạo"), preserve_default=False),
        migrations.AddField(model_name="xa", name="updated_at", field=models.DateTimeField(auto_now=True, verbose_name="Ngày cập nhật")),
        migrations.AddField(model_name="xa", name="is_active", field=models.BooleanField(default=True, verbose_name="Đang sử dụng")),
        migrations.AlterField(model_name="xa", name="tinh", field=models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="danh_sach_xa", to="quanly.tinh", verbose_name="Thuộc Tỉnh")),
        migrations.AddField(model_name="donvi", name="created_at", field=models.DateTimeField(auto_now_add=True, default=timezone.now, verbose_name="Ngày tạo"), preserve_default=False),
        migrations.AddField(model_name="donvi", name="updated_at", field=models.DateTimeField(auto_now=True, verbose_name="Ngày cập nhật")),
        migrations.AddField(model_name="donvi", name="is_active", field=models.BooleanField(default=True, verbose_name="Đang sử dụng")),
        migrations.AlterField(model_name="donvi", name="mstdv", field=models.CharField(blank=True, max_length=20, null=True, unique=True, verbose_name="Mã số thuế")),
        migrations.AddField(model_name="canbo", name="created_at", field=models.DateTimeField(auto_now_add=True, default=timezone.now, verbose_name="Ngày tạo"), preserve_default=False),
        migrations.AddField(model_name="canbo", name="updated_at", field=models.DateTimeField(auto_now=True, verbose_name="Ngày cập nhật")),
        migrations.AddField(model_name="canbo", name="is_active", field=models.BooleanField(default=True, verbose_name="Đang hoạt động")),
        migrations.AlterField(model_name="canbo", name="tinh", field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, to="quanly.tinh", verbose_name="Tỉnh/Thành phố")),
        migrations.AlterField(model_name="canbo", name="xa", field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, to="quanly.xa", verbose_name="Xã/Phường")),
        migrations.AlterField(model_name="canbo", name="don_vi", field=models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, to="quanly.donvi", verbose_name="Đơn vị trực thuộc")),
        migrations.AlterField(model_name="canbo", name="noi_cap", field=models.CharField(blank=True, max_length=200, null=True, verbose_name="Nơi cấp")),
        migrations.AddField(model_name="nhomhd", name="created_at", field=models.DateTimeField(auto_now_add=True, default=timezone.now, verbose_name="Ngày tạo"), preserve_default=False),
        migrations.AddField(model_name="nhomhd", name="updated_at", field=models.DateTimeField(auto_now=True, verbose_name="Ngày cập nhật")),
        migrations.AddField(model_name="nhomhd", name="is_active", field=models.BooleanField(default=True, verbose_name="Đang sử dụng")),
        migrations.AddField(model_name="tre", name="created_at", field=models.DateTimeField(auto_now_add=True, default=timezone.now, verbose_name="Ngày tạo"), preserve_default=False),
        migrations.AddField(model_name="tre", name="updated_at", field=models.DateTimeField(auto_now=True, verbose_name="Ngày cập nhật")),
        migrations.AddField(model_name="tre", name="is_active", field=models.BooleanField(default=True, verbose_name="Đang sử dụng")),
        migrations.AlterField(model_name="tre", name="ma_tinh", field=models.CharField(blank=True, max_length=10, null=True, verbose_name="Mã tỉnh")),
        migrations.AlterField(model_name="tre", name="tinh", field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, to="quanly.tinh", verbose_name="Tỉnh/Thành phố")),
        migrations.AlterField(model_name="tre", name="xa", field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, to="quanly.xa", verbose_name="Xã/Phường")),

        # Phân bổ: loại bỏ toàn bộ thuộc tính của HĐ cũ, giữ lại đúng nghiệp vụ phân bổ.
        migrations.RemoveField(model_name="phanbochitieu", name="so_hop_dong"),
        migrations.RemoveField(model_name="phanbochitieu", name="ngay_ky"),
        migrations.RemoveField(model_name="phanbochitieu", name="tu_ngay"),
        migrations.RemoveField(model_name="phanbochitieu", name="den_ngay"),
        migrations.RemoveField(model_name="phanbochitieu", name="gia_tri_hd_du_kien"),
        migrations.RemoveField(model_name="phanbochitieu", name="trang_thai"),
        migrations.RemoveField(model_name="phanbochitieu", name="ngay_lap_de_xuat"),
        migrations.AddField(model_name="phanbochitieu", name="created_at", field=models.DateTimeField(auto_now_add=True, default=timezone.now, verbose_name="Ngày tạo"), preserve_default=False),
        migrations.AddField(model_name="phanbochitieu", name="updated_at", field=models.DateTimeField(auto_now=True, verbose_name="Ngày cập nhật")),
        migrations.AddField(model_name="phanbochitieu", name="ngay_lap", field=models.DateField(default=timezone.now, verbose_name="Ngày lập phân bổ")),
        migrations.AddField(model_name="phanbochitieu", name="ghi_chu", field=models.TextField(blank=True, null=True, verbose_name="Ghi chú")),
        migrations.AlterField(model_name="phanbochitieu", name="can_bo", field=models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="phan_bo_chi_tieu", to="quanly.canbo", verbose_name="Cán bộ chuyên trách")),
        migrations.AlterField(model_name="phanbochitieu", name="nhom_hd", field=models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="phan_bo_chi_tieu", to="quanly.nhomhd", verbose_name="Nhóm hợp đồng")),
        migrations.AlterField(model_name="phanbochitieu", name="so_tre_phcn", field=models.PositiveIntegerField(default=0, verbose_name="Số trẻ PHCN")),
        migrations.AlterField(model_name="phanbochitieu", name="so_buoi_phcn", field=models.PositiveIntegerField(default=20, verbose_name="Số buổi/trẻ PHCN")),
        migrations.AlterField(model_name="phanbochitieu", name="dinh_muc_di_lai_phcn", field=models.DecimalField(decimal_places=0, default=Decimal("50000"), max_digits=12, verbose_name="Định mức đi lại PHCN")),
        migrations.AlterField(model_name="phanbochitieu", name="so_tre_cs", field=models.PositiveIntegerField(default=0, verbose_name="Số trẻ CSXH")),
        migrations.AlterField(model_name="phanbochitieu", name="so_buoi_cs", field=models.PositiveIntegerField(default=10, verbose_name="Số buổi/trẻ CSXH")),
        migrations.AlterField(model_name="phanbochitieu", name="dinh_muc_di_lai_cs", field=models.DecimalField(decimal_places=0, default=Decimal("50000"), max_digits=12, verbose_name="Định mức đi lại CSXH")),
        migrations.AlterField(model_name="phanbochitieu", name="is_locked", field=models.BooleanField(default=False, verbose_name="Đã khóa")),

        # Phân công: đổi FK HĐ cũ thành FK Phân bổ; chuẩn hóa kỳ/đợt sang số.
        migrations.RenameField(model_name="phancongtre", old_name="hop_dong", new_name="phan_bo"),
        migrations.AddField(model_name="phancongtre", name="created_at", field=models.DateTimeField(auto_now_add=True, default=timezone.now, verbose_name="Ngày tạo"), preserve_default=False),
        migrations.AddField(model_name="phancongtre", name="updated_at", field=models.DateTimeField(auto_now=True, verbose_name="Ngày cập nhật")),
        migrations.AddField(model_name="phancongtre", name="ghi_chu", field=models.TextField(blank=True, null=True, verbose_name="Ghi chú")),
        migrations.AlterField(model_name="phancongtre", name="phan_bo", field=models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="danh_sach_phan_cong", to="quanly.phanbochitieu", verbose_name="Phân bổ chỉ tiêu")),
        migrations.AlterField(model_name="phancongtre", name="tre", field=models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="danh_sach_phan_cong", to="quanly.tre", verbose_name="Trẻ")),
        migrations.AlterField(model_name="phancongtre", name="loai_dich_vu", field=models.CharField(choices=[("VLTL", "Vật lý trị liệu"), ("HDTL", "Hoạt động trị liệu"), ("NNTL", "Ngôn ngữ trị liệu"), ("GDDB", "Giáo dục đặc biệt"), ("CSXH", "Chăm sóc xã hội"), ("CSYT", "Chăm sóc y tế")], max_length=10, verbose_name="Loại dịch vụ")),
        migrations.AlterField(model_name="phancongtre", name="so_buoi_du_kien", field=models.PositiveIntegerField(default=0, verbose_name="Số buổi dự kiến")),
        migrations.AlterField(model_name="phancongtre", name="dot_phan_cong", field=models.PositiveIntegerField(default=1, verbose_name="Đợt phân công")),
        migrations.AlterField(model_name="phancongtre", name="ky_phan_cong", field=models.PositiveIntegerField(default=1, verbose_name="Kỳ phân công")),
        migrations.AlterField(model_name="phancongtre", name="dinh_muc_di_lai", field=models.DecimalField(decimal_places=0, default=Decimal("0"), max_digits=12, verbose_name="Định mức đi lại")),
        migrations.AlterField(model_name="phancongtre", name="trang_thai", field=models.CharField(choices=[("DANG_CAN_THIEP", "Đang can thiệp"), ("DA_HOAN_THANH", "Đã hoàn thành"), ("KHONG_CAN_THIEP", "Không can thiệp")], default="DANG_CAN_THIEP", max_length=20, verbose_name="Trạng thái")),

        migrations.RunPython(
            drop_renamed_hopdong_canbo_fk,
            migrations.RunPython.noop,
            atomic=False,
        ),

        # HĐ chính thức.
        migrations.CreateModel(
            name="DeXuatHopDong",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("created_at", models.DateTimeField(auto_now_add=True, verbose_name="Ngày tạo")),
                ("updated_at", models.DateTimeField(auto_now=True, verbose_name="Ngày cập nhật")),
                ("lan_de_xuat", models.PositiveIntegerField(default=1, verbose_name="Lần đề xuất")),
                ("ngay_de_xuat", models.DateField(default=timezone.now, verbose_name="Ngày đề xuất")),
                ("so_tre_phcn", models.PositiveIntegerField(default=0, verbose_name="Số trẻ PHCN")),
                ("so_buoi_phcn", models.PositiveIntegerField(default=0, verbose_name="Số buổi PHCN")),
                ("so_tre_cs", models.PositiveIntegerField(default=0, verbose_name="Số trẻ CSXH")),
                ("so_buoi_cs", models.PositiveIntegerField(default=0, verbose_name="Số buổi CSXH")),
                ("gia_tri_du_kien", models.DecimalField(decimal_places=0, default=Decimal("0"), max_digits=18, verbose_name="Giá trị dự kiến")),
                ("trang_thai", models.CharField(choices=[("CHO_KIEM_TRA", "Chờ kiểm tra"), ("DU_DIEU_KIEN", "Đủ điều kiện"), ("DA_DUYET", "Đã duyệt"), ("DA_TAO_HOP_DONG", "Đã tạo hợp đồng"), ("TU_CHOI", "Từ chối"), ("HUY", "Hủy")], default="CHO_KIEM_TRA", max_length=30, verbose_name="Trạng thái")),
                ("ly_do", models.TextField(blank=True, null=True, verbose_name="Lý do/Ghi chú")),
                ("phan_bo", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="de_xuat_hop_dong", to="quanly.phanbochitieu", verbose_name="Phân bổ chỉ tiêu")),
            ],
            options={"indexes": [models.Index(fields=["trang_thai", "ngay_de_xuat"], name="idx_dexuat_status_ngay")]},
        ),
        migrations.AddConstraint(model_name="dexuathopdong", constraint=models.UniqueConstraint(fields=["phan_bo", "lan_de_xuat"], name="uq_dexuat_phanbo_lan")),
        migrations.CreateModel(
            name="HopDong",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("created_at", models.DateTimeField(auto_now_add=True, verbose_name="Ngày tạo")),
                ("updated_at", models.DateTimeField(auto_now=True, verbose_name="Ngày cập nhật")),
                ("so_hop_dong", models.CharField(max_length=50, unique=True, verbose_name="Số hợp đồng")),
                ("ngay_ky", models.DateField(blank=True, null=True, verbose_name="Ngày ký")),
                ("tu_ngay", models.DateField(verbose_name="Từ ngày")),
                ("den_ngay", models.DateField(verbose_name="Đến ngày")),
                ("don_gia_cong", models.DecimalField(decimal_places=0, default=Decimal("200000"), max_digits=12, verbose_name="Đơn giá công")),
                ("dinh_muc_di_lai_phcn", models.DecimalField(decimal_places=0, default=Decimal("50000"), max_digits=12, verbose_name="Định mức đi lại PHCN")),
                ("dinh_muc_di_lai_cs", models.DecimalField(decimal_places=0, default=Decimal("50000"), max_digits=12, verbose_name="Định mức đi lại CSXH")),
                ("gia_tri_hop_dong", models.DecimalField(decimal_places=0, default=Decimal("0"), max_digits=18, verbose_name="Giá trị hợp đồng")),
                ("trang_thai", models.CharField(choices=[("DU_THAO", "Dự thảo"), ("DA_KY", "Đã ký"), ("DANG_THUC_HIEN", "Đang thực hiện"), ("TAM_DUNG", "Tạm dừng"), ("HET_HAN", "Hết hạn"), ("NGHIEM_THU", "Nghiệm thu"), ("THANH_LY", "Thanh lý"), ("HUY", "Hủy")], default="DU_THAO", max_length=20, verbose_name="Trạng thái")),
                ("is_locked", models.BooleanField(default=False, verbose_name="Đã khóa")),
                ("ghi_chu", models.TextField(blank=True, null=True, verbose_name="Ghi chú")),
                ("de_xuat", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="hop_dong", to="quanly.dexuathopdong", verbose_name="Đề xuất hợp đồng")),
                ("can_bo", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="hop_dong", to="quanly.canbo", verbose_name="Cán bộ chuyên trách")),
                ("nhom_hd", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="hop_dong", to="quanly.nhomhd", verbose_name="Nhóm hợp đồng")),
            ],
            options={"indexes": [models.Index(fields=["can_bo", "trang_thai"], name="idx_hd_cb_status"), models.Index(fields=["tu_ngay", "den_ngay"], name="idx_hd_range")]},
        ),
        migrations.AddConstraint(model_name="hopdong", constraint=models.CheckConstraint(condition=models.Q(den_ngay__gte=models.F("tu_ngay")), name="ck_hd_ngay_hop_le")),
        migrations.AddConstraint(model_name="hopdong", constraint=models.CheckConstraint(condition=models.Q(gia_tri_hop_dong__gte=0), name="ck_hd_gia_tri_duong")),

        migrations.CreateModel(
            name="ChiTietKhoiLuongHopDong",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("created_at", models.DateTimeField(auto_now_add=True, verbose_name="Ngày tạo")),
                ("updated_at", models.DateTimeField(auto_now=True, verbose_name="Ngày cập nhật")),
                ("loai_dich_vu", models.CharField(choices=[("VLTL", "Vật lý trị liệu"), ("HDTL", "Hoạt động trị liệu"), ("NNTL", "Ngôn ngữ trị liệu"), ("GDDB", "Giáo dục đặc biệt"), ("CSXH", "Chăm sóc xã hội"), ("CSYT", "Chăm sóc y tế")], max_length=10, verbose_name="Loại dịch vụ")),
                ("so_tre", models.PositiveIntegerField(default=0, verbose_name="Số trẻ")),
                ("so_buoi", models.PositiveIntegerField(default=0, verbose_name="Số buổi")),
                ("don_gia_cong", models.DecimalField(decimal_places=0, max_digits=12, verbose_name="Đơn giá công")),
                ("dinh_muc_di_lai", models.DecimalField(decimal_places=0, max_digits=12, verbose_name="Định mức đi lại")),
                ("thanh_tien", models.DecimalField(decimal_places=0, default=Decimal("0"), max_digits=18, verbose_name="Thành tiền")),
                ("hop_dong", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="chi_tiet_khoi_luong", to="quanly.hopdong", verbose_name="Hợp đồng")),
            ],
        ),
        migrations.AddConstraint(model_name="chitietkhoiluonghopdong", constraint=models.UniqueConstraint(fields=["hop_dong", "loai_dich_vu"], name="uq_hd_khoiluong_dv")),

        migrations.CreateModel(
            name="PhuLucHopDong",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("created_at", models.DateTimeField(auto_now_add=True, verbose_name="Ngày tạo")),
                ("updated_at", models.DateTimeField(auto_now=True, verbose_name="Ngày cập nhật")),
                ("loai_phu_luc", models.CharField(choices=[("KY_1", "Phụ lục phân công Kỳ 1"), ("BO_SUNG", "Phụ lục bổ sung"), ("DIEU_CHINH", "Phụ lục điều chỉnh"), ("KHAC", "Phụ lục khác")], max_length=20, verbose_name="Loại phụ lục")),
                ("so_phu_luc", models.CharField(blank=True, max_length=50, null=True, verbose_name="Số phụ lục")),
                ("ngay_lap", models.DateField(default=timezone.now, verbose_name="Ngày lập")),
                ("is_signed", models.BooleanField(default=False, verbose_name="Đã ký")),
                ("ghi_chu", models.TextField(blank=True, null=True, verbose_name="Ghi chú")),
                ("hop_dong", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="phu_luc", to="quanly.hopdong", verbose_name="Hợp đồng")),
            ],
            options={"indexes": [models.Index(fields=["hop_dong", "loai_phu_luc"], name="idx_pl_hd_loai")]},
        ),
        migrations.CreateModel(
            name="ChiTietPhuLucPhanCong",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("created_at", models.DateTimeField(auto_now_add=True, verbose_name="Ngày tạo")),
                ("updated_at", models.DateTimeField(auto_now=True, verbose_name="Ngày cập nhật")),
                ("ma_tre", models.CharField(max_length=20, verbose_name="Mã trẻ")),
                ("ten_tre", models.CharField(max_length=100, verbose_name="Tên trẻ")),
                ("ma_can_bo", models.CharField(max_length=20, verbose_name="Mã CBCT")),
                ("ten_can_bo", models.CharField(max_length=100, verbose_name="Tên CBCT")),
                ("loai_dich_vu", models.CharField(choices=[("VLTL", "Vật lý trị liệu"), ("HDTL", "Hoạt động trị liệu"), ("NNTL", "Ngôn ngữ trị liệu"), ("GDDB", "Giáo dục đặc biệt"), ("CSXH", "Chăm sóc xã hội"), ("CSYT", "Chăm sóc y tế")], max_length=10, verbose_name="Loại dịch vụ")),
                ("dot_phan_cong", models.PositiveIntegerField(default=1, verbose_name="Đợt phân công")),
                ("ky_phan_cong", models.PositiveIntegerField(default=1, verbose_name="Kỳ phân công")),
                ("ngay_phan_cong", models.DateField(blank=True, null=True, verbose_name="Ngày phân công")),
                ("so_buoi_du_kien", models.PositiveIntegerField(default=0, verbose_name="Số buổi dự kiến")),
                ("dinh_muc_di_lai", models.DecimalField(decimal_places=0, default=Decimal("0"), max_digits=12, verbose_name="Định mức đi lại")),
                ("dia_diem_ct", models.CharField(blank=True, max_length=255, null=True, verbose_name="Địa điểm can thiệp")),
                ("hinh_thuc_ct", models.CharField(blank=True, max_length=100, null=True, verbose_name="Hình thức can thiệp")),
                ("ghi_chu", models.TextField(blank=True, null=True, verbose_name="Ghi chú")),
                ("phu_luc", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="chi_tiet_phan_cong", to="quanly.phuluchopdong", verbose_name="Phụ lục")),
                ("source_phan_cong", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="snapshot_phu_luc", to="quanly.phancongtre", verbose_name="Phân công nguồn")),
            ],
            options={"indexes": [models.Index(fields=["phu_luc", "ky_phan_cong"], name="idx_ctpl_ky"), models.Index(fields=["ma_tre", "loai_dich_vu"], name="idx_ctpl_tre_dv")]},
        ),
        migrations.CreateModel(
            name="NhatKyThucHien",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("created_at", models.DateTimeField(auto_now_add=True, verbose_name="Ngày tạo")),
                ("updated_at", models.DateTimeField(auto_now=True, verbose_name="Ngày cập nhật")),
                ("ngay_thuc_hien", models.DateField(verbose_name="Ngày thực hiện")),
                ("so_buoi_thuc_hien", models.PositiveIntegerField(default=1, verbose_name="Số buổi thực hiện")),
                ("so_luot_di_lai", models.PositiveIntegerField(default=1, verbose_name="Số lượt đi lại")),
                ("don_gia_cong", models.DecimalField(decimal_places=0, max_digits=12, verbose_name="Đơn giá công")),
                ("dinh_muc_di_lai", models.DecimalField(decimal_places=0, max_digits=12, verbose_name="Định mức đi lại")),
                ("thanh_tien", models.DecimalField(decimal_places=0, default=Decimal("0"), max_digits=18, verbose_name="Thành tiền")),
                ("ghi_chu", models.TextField(blank=True, null=True, verbose_name="Ghi chú")),
                ("hop_dong", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="nhat_ky_thuc_hien", to="quanly.hopdong", verbose_name="Hợp đồng")),
                ("phan_cong", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="nhat_ky_thuc_hien", to="quanly.phancongtre", verbose_name="Phân công")),
            ],
            options={"indexes": [models.Index(fields=["hop_dong", "ngay_thuc_hien"], name="idx_nk_hd_ngay"), models.Index(fields=["phan_cong", "ngay_thuc_hien"], name="idx_nk_pc_ngay")]},
        ),
        migrations.AddConstraint(model_name="nhatkythuchien", constraint=models.CheckConstraint(condition=models.Q(so_buoi_thuc_hien__gt=0), name="ck_nk_so_buoi_gt0")),
        migrations.AddConstraint(model_name="nhatkythuchien", constraint=models.CheckConstraint(condition=models.Q(so_luot_di_lai__gte=0), name="ck_nk_di_lai_gte0")),
        migrations.CreateModel(
            name="DotThanhToan",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("created_at", models.DateTimeField(auto_now_add=True, verbose_name="Ngày tạo")),
                ("updated_at", models.DateTimeField(auto_now=True, verbose_name="Ngày cập nhật")),
                ("nam", models.PositiveIntegerField(verbose_name="Năm")),
                ("thang", models.PositiveSmallIntegerField(verbose_name="Tháng")),
                ("ngay_de_nghi", models.DateField(default=timezone.now, verbose_name="Ngày đề nghị")),
                ("trang_thai", models.CharField(default="CHO_THANH_TOAN", max_length=30, verbose_name="Trạng thái")),
                ("ghi_chu", models.TextField(blank=True, null=True, verbose_name="Ghi chú")),
                ("hop_dong", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="dot_thanh_toan", to="quanly.hopdong", verbose_name="Hợp đồng")),
            ],
            options={"ordering": ["-nam", "-thang", "-id"]},
        ),
        migrations.AddConstraint(model_name="dotthanhtoan", constraint=models.UniqueConstraint(fields=["hop_dong", "nam", "thang"], name="uq_dottt_hd_nam_thang")),
        migrations.AddConstraint(model_name="dotthanhtoan", constraint=models.CheckConstraint(condition=models.Q(thang__gte=1, thang__lte=12), name="ck_dottt_thang")),
        migrations.CreateModel(
            name="ChiTietThanhToan",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("created_at", models.DateTimeField(auto_now_add=True, verbose_name="Ngày tạo")),
                ("updated_at", models.DateTimeField(auto_now=True, verbose_name="Ngày cập nhật")),
                ("so_buoi_thanh_toan", models.PositiveIntegerField(default=0, verbose_name="Số buổi thanh toán")),
                ("so_luot_di_lai", models.PositiveIntegerField(default=0, verbose_name="Số lượt đi lại thanh toán")),
                ("thanh_tien", models.DecimalField(decimal_places=0, default=Decimal("0"), max_digits=18, verbose_name="Thành tiền")),
                ("ghi_chu", models.TextField(blank=True, null=True, verbose_name="Ghi chú")),
                ("dot_thanh_toan", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="chi_tiet", to="quanly.dotthanhtoan", verbose_name="Đợt thanh toán")),
                ("nhat_ky", models.OneToOneField(on_delete=django.db.models.deletion.PROTECT, related_name="chi_tiet_thanh_toan", to="quanly.nhatkythuchien", verbose_name="Nhật ký thực hiện")),
            ],
        ),
        migrations.CreateModel(
            name="NghiemThu",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("created_at", models.DateTimeField(auto_now_add=True, verbose_name="Ngày tạo")),
                ("updated_at", models.DateTimeField(auto_now=True, verbose_name="Ngày cập nhật")),
                ("ngay_nghiem_thu", models.DateField(blank=True, null=True, verbose_name="Ngày nghiệm thu")),
                ("ket_qua", models.CharField(default="DAT", max_length=30, verbose_name="Kết quả")),
                ("gia_tri_nghiem_thu", models.DecimalField(decimal_places=0, default=Decimal("0"), max_digits=18, verbose_name="Giá trị nghiệm thu")),
                ("bien_ban_so", models.CharField(blank=True, max_length=50, null=True, verbose_name="Số biên bản")),
                ("ghi_chu", models.TextField(blank=True, null=True, verbose_name="Ghi chú")),
                ("hop_dong", models.OneToOneField(on_delete=django.db.models.deletion.PROTECT, related_name="nghiem_thu", to="quanly.hopdong", verbose_name="Hợp đồng")),
            ],
        ),
        migrations.CreateModel(
            name="ThanhLyHopDong",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("created_at", models.DateTimeField(auto_now_add=True, verbose_name="Ngày tạo")),
                ("updated_at", models.DateTimeField(auto_now=True, verbose_name="Ngày cập nhật")),
                ("ngay_thanh_ly", models.DateField(blank=True, null=True, verbose_name="Ngày thanh lý")),
                ("gia_tri_thanh_ly", models.DecimalField(decimal_places=0, default=Decimal("0"), max_digits=18, verbose_name="Giá trị thanh lý")),
                ("bien_ban_so", models.CharField(blank=True, max_length=50, null=True, verbose_name="Số biên bản")),
                ("ghi_chu", models.TextField(blank=True, null=True, verbose_name="Ghi chú")),
                ("hop_dong", models.OneToOneField(on_delete=django.db.models.deletion.PROTECT, related_name="thanh_ly", to="quanly.hopdong", verbose_name="Hợp đồng")),
            ],
        ),

        # Đồng bộ trạng thái model cũ và các Meta options với models.py hiện tại.
        migrations.AlterField(
            model_name="canbo",
            name="gioi_tinh",
            field=models.CharField(
                choices=[("Nam", "Nam"), ("Nữ", "Nữ"), ("Khác", "Khác")],
                blank=True,
                null=True,
                max_length=10,
                verbose_name="Giới tính",
            ),
        ),
        migrations.AlterField(
            model_name="tre",
            name="ten_phu_huynh",
            field=models.CharField(blank=True, null=True, max_length=100, verbose_name="Tên phụ huynh"),
        ),
        migrations.AddIndex(model_name="phanbochitieu", index=models.Index(fields=["can_bo", "ngay_lap"], name="idx_pbct_cb_ngay")),
        migrations.AddIndex(model_name="phanbochitieu", index=models.Index(fields=["nhom_hd", "ngay_lap"], name="idx_pbct_nhom_ngay")),
        migrations.AddIndex(model_name="phancongtre", index=models.Index(fields=["phan_bo", "dot_phan_cong"], name="idx_pct_pb_dot")),
        migrations.AddIndex(model_name="phancongtre", index=models.Index(fields=["tre", "ky_phan_cong"], name="idx_pct_tre_ky")),
        migrations.AddIndex(model_name="phancongtre", index=models.Index(fields=["loai_dich_vu", "ngay_phan_cong"], name="idx_pct_dv_ngay")),
        migrations.AddConstraint(
            model_name="xa",
            constraint=models.UniqueConstraint(fields=["tinh", "ten_xa"], name="uq_xa_tinh_ten"),
        ),
        migrations.AlterModelOptions(
            name="canbo",
            options={"ordering": ["ho_ten"], "verbose_name": "Cán bộ chuyên trách", "verbose_name_plural": "Cán bộ chuyên trách"},
        ),
        migrations.AlterModelOptions(
            name="donvi",
            options={"ordering": ["ten_don_vi"], "verbose_name": "Đơn vị", "verbose_name_plural": "Đơn vị"},
        ),
        migrations.AlterModelOptions(
            name="hopdong",
            options={"ordering": ["-ngay_ky", "-id"]},
        ),
        migrations.AlterModelOptions(
            name="nhatkythuchien",
            options={"ordering": ["-ngay_thuc_hien", "-id"]},
        ),
        migrations.AlterModelOptions(
            name="nhomhd",
            options={"ordering": ["ma_nhom_hd"], "verbose_name": "Nhóm hợp đồng", "verbose_name_plural": "Nhóm hợp đồng"},
        ),
        migrations.AlterModelOptions(
            name="phanbochitieu",
            options={"ordering": ["-ngay_lap", "-id"]},
        ),
        migrations.AlterModelOptions(
            name="phancongtre",
            options={"ordering": ["-ngay_phan_cong", "-id"]},
        ),
        migrations.AlterModelOptions(
            name="phuluchopdong",
            options={"ordering": ["-ngay_lap", "-id"]},
        ),
        migrations.AlterModelOptions(
            name="tinh",
            options={"ordering": ["ten_tinh"], "verbose_name": "Tỉnh/Thành phố", "verbose_name_plural": "Tỉnh/Thành phố"},
        ),
        migrations.AlterModelOptions(
            name="tre",
            options={"ordering": ["ma_tre"], "verbose_name": "Trẻ", "verbose_name_plural": "Trẻ"},
        ),
        migrations.AlterModelOptions(
            name="xa",
            options={"ordering": ["ten_xa"], "verbose_name": "Xã/Phường", "verbose_name_plural": "Xã/Phường"},
        ),
        migrations.DeleteModel(name="ChiTieuHopDong"),
    ]
